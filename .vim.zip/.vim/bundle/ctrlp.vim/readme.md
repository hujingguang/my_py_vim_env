# ctrlp.vim
Fuzzy __file__, __buffer__, __mru__, __tag__, ... finder for Vim.

* [**Project's homepage**][1]
* [**Main git repository**][2]

[1]: http://kien.github.com/ctrlp.vim
[2]: https://github.com/kien/ctrlp.vim
