""" Python-mode async support. """

from ._compat import Queue


RESULTS = Queue()
