import os


def func():
    
